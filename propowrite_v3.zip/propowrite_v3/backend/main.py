import os
from pathlib import Path
from string import Template
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import openai

openai.api_key = os.getenv("OPENAI_API_KEY")
if not openai.api_key:
    raise RuntimeError("OPENAI_API_KEY env var missing")

TEMPLATE = Template((Path(__file__).parent.parent / "templates" / "proposal_prompt.txt").read_text())

class Req(BaseModel):
    discipline: str
    client_name: str
    project_name: str
    site_description: str
    services_required: str
    budget: str
    deadline: str

app = FastAPI(title="PropoWrite", version="0.3")

@app.post("/generate-proposal")
async def gen(data: Req):
    prompt = TEMPLATE.substitute(**data.dict())
    try:
        resp = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-0125",
            messages=[{"role":"user","content":prompt}],
            temperature=0.7
        )
        return {"proposal_markdown": resp.choices[0].message.content.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
